<?php

defined('BASEPATH') OR exit('Ação não permitida');

class Servicos extends CI_Controller{

	public function __construct(){
		parent:: __construct();

		if(!$this->ion_auth->logged_in()){
			$this->session->set_flashdata('info', 'Sua sessão expirou!');
			redirect('login');

		}

	}

	public function index(){

		$data = array(
		

			'titulo' => 'Serviços cadastrados',

			'styles' => array(
				'vendor/datatables/dataTables.bootstrap4.min.css',
			),

			'scripts' => array(
				'vendor/datatables/jquery.dataTables.min.js', 
				'vendor/datatables/dataTables.bootstrap4.min.js',
				'vendor/datatables/app.js'
			),


			'servicos' => $this->core_model->get_all('servicos'),

		);

		//echo '<pre>';
		//print_r($data['vendedores']);
		//exit();

		$this->load->view('layout/header', $data);
		$this->load->view('servicos/index');
		$this->load->view('layout/footer');

	}

	public function add(){

		$this->form_validation->set_rules('servico_nome', '', 'trim|required|min_length[10]|max_length[145]');
			
			$this->form_validation->set_rules('servico_preco', '', 'trim|required');

			$this->form_validation->set_rules('servico_descricao', '', 'trim|required|max_length[700]');

			//$this->form_validation->set_rules('vendedor_email', '', 'trim|required|valid_email|max_length[50]|callback_check_vendedor_email');
		
			//$this->form_validation->set_rules('vendedor_telefone', '', 'trim|required|max_length[14]|callback_check_vendedor_telefone');
			//$this->form_validation->set_rules('vendedor_celular', '', 'trim|required|max_length[15]|callback_check_vendedor_celular');

			//$this->form_validation->set_rules('vendedor_cep', '', 'trim|required|exact_length[9]');
			//$this->form_validation->set_rules('vendedor_endereco', '', 'trim|required|max_length[155]');
			//$this->form_validation->set_rules('vendedor_numero_endereco', '', 'trim|max_length[20]');
			//$this->form_validation->set_rules('vendedor_bairro', '', 'trim|required|max_length[45]');
			//$this->form_validation->set_rules('vendedor_complemento', '', 'trim|max_length[145]');
			//$this->form_validation->set_rules('vendedor_cidade', '', 'trim|required|max_length[50]');
			//$this->form_validation->set_rules('vendedor_estado', '', 'trim|required|exact_length[2]');
			//$this->form_validation->set_rules('vendedor_obs', '', 'max_length[500]');

			if($this->form_validation->run()){

				$data = elements(

				array(
					'servico_nome',
					'servico_preco',
					'servico_descricao',
					'servico_ativo',
				), $this->input->post()

			);

				//$data['cliente_estado'] = strtoupper($this->input->post('cliente_estado'));

			$data = html_escape($data);

			$this->core_model->insert('servicos', $data);

			redirect('servicos');

			}else{

				$data = array(

					'titulo' => 'Cadastrar serviços', 

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js', 
						'vendor/mask/app.js',
					),
				

				);

				//echo '<pre>';
				//print_r($data['vendedores']);
				//exit();

				$this->load->view('layout/header', $data);
				$this->load->view('servicos/add');
				$this->load->view('layout/footer');

			}

	}

	public function edit($servico_id = NULL){

		if(!$servico_id || !$this->core_model->get_by_id('servicos', array('servico_id' => $servico_id))){

				$this->session->set_flashdata('error', 'Serviço não encontrado!');
				redirect('servicos');

		}else{

			$this->form_validation->set_rules('servico_nome', '', 'trim|required|min_length[10]|max_length[145]');
			
			$this->form_validation->set_rules('servico_preco', '', 'trim|required');

			$this->form_validation->set_rules('servico_descricao', '', 'trim|required|max_length[700]');

			//$this->form_validation->set_rules('vendedor_email', '', 'trim|required|valid_email|max_length[50]|callback_check_vendedor_email');
		
			//$this->form_validation->set_rules('vendedor_telefone', '', 'trim|required|max_length[14]|callback_check_vendedor_telefone');
			//$this->form_validation->set_rules('vendedor_celular', '', 'trim|required|max_length[15]|callback_check_vendedor_celular');

			//$this->form_validation->set_rules('vendedor_cep', '', 'trim|required|exact_length[9]');
			//$this->form_validation->set_rules('vendedor_endereco', '', 'trim|required|max_length[155]');
			//$this->form_validation->set_rules('vendedor_numero_endereco', '', 'trim|max_length[20]');
			//$this->form_validation->set_rules('vendedor_bairro', '', 'trim|required|max_length[45]');
			//$this->form_validation->set_rules('vendedor_complemento', '', 'trim|max_length[145]');
			//$this->form_validation->set_rules('vendedor_cidade', '', 'trim|required|max_length[50]');
			//$this->form_validation->set_rules('vendedor_estado', '', 'trim|required|exact_length[2]');
			//$this->form_validation->set_rules('vendedor_obs', '', 'max_length[500]');

			if($this->form_validation->run()){

				$data = elements(

				array(
					'servico_nome',
					'servico_preco',
					'servico_descricao',
					'servico_ativo',
				), $this->input->post()

			);

				//$data['cliente_estado'] = strtoupper($this->input->post('cliente_estado'));

			$data = html_escape($data);

			$this->core_model->update('servicos', $data, array('servico_id' => $servico_id));

			redirect('servicos');

			}else{

				$data = array(

					'titulo' => 'Atualizar serviços', 

					'scripts' => array(
						'vendor/mask/jquery.mask.min.js', 
						'vendor/mask/app.js',
					),
				
					'servico' => $this->core_model->get_by_id('servicos', array('servico_id' => $servico_id)),

				);

				//echo '<pre>';
				//print_r($data['vendedores']);
				//exit();

				$this->load->view('layout/header', $data);
				$this->load->view('servicos/edit');
				$this->load->view('layout/footer');

			}

		}

	}

	public function del($servico_id = NULL){

    	if(!$servico_id || !$this->core_model->get_by_id('servicos', array('servico_id' => $servico_id))){

    		$this->session->set_flashdata('error', 'Serviço não encontrado!');
    		redirect('servicos');

    	}else{

    		$this->core_model->delete('servicos', array('servico_id' => $servico_id));
    		$this->session->set_flashdata('sucesso', 'Serviço deletado com sucesso!');
    		redirect('servicos');

    	}

    }

}