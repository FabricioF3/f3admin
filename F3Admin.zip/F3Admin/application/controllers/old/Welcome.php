<?php
defined('BASEPATH') OR exit('Ação não permitida');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('chamou');
	}
}
