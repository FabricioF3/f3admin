	
<?php $this->load->view('layout/sidebar'); ?>


<!-- Main Content -->
<div id="content">

 <?php $this->load->view('layout/navbar'); ?>

 <!-- Begin Page Content -->
 <div class="container-fluid">

  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo base_url('clientes'); ?>">Clientes</a></li>
      <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
    </ol>
  </nav>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-body">

      <form class="user" method="POST" name="form_add">

        <div class="custom-control custom-radio custom-control-inline mt-2">
          <input type="radio" id="pessoa_fisica" name="cliente_tipo" class="custom-control-input" value="1" <?php echo set_checkbox('cliente_tipo', '1') ?> checked="">
          <label class="custom-control-label pt-1" for="pessoa_fisica">Pessoa física</label>
        </div>
        <div class="custom-control custom-radio custom-control-inline">
          <input type="radio" id="pessoa_juridica" name="cliente_tipo" class="custom-control-input" value="2" <?php echo set_checkbox('cliente_tipo', '2') ?> >
          <label class="custom-control-label pt-1" for="pessoa_juridica">Pessoa jurídica</label>
        </div>

        <fieldset class="mt-4 border p-2">
          <legend class="font-small"><i class="fas fa-user-tie"></i>&nbsp;Dados pessoais</legend>

          <div class="form-group row mb-4">

            <div class="col-md-3">
              <label>Nome <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="cliente_nome" placeholder="Nome do cliente" value="<?php echo set_value('cliente_nome'); ?>">
              <?php echo form_error('cliente_nome', '<small class="form-text text-danger">','</small>'); ?>
            </div>

            <div class="col-md-3">
              <label>Sobrenome <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="cliente_sobrenome" placeholder="Sobrenome do cliente" value="<?php echo set_value('cliente_sobrenome'); ?>">
              <?php echo form_error('cliente_sobrenome', '<small class="form-text text-danger">','</small>'); ?>
            </div>

            <div class="col-md-3">
              <div class="pessoa_fisica">
                <label>CPF <span class="text-danger">*</span></label>
                <input type="text" class="form-control cpf" name="cliente_cpf" placeholder="CPF do cliente" value="<?php echo set_value('cliente_cpf'); ?>">
                <?php echo form_error('cliente_cpf', '<small class="form-text text-danger">','</small>'); ?>
              </div>
              <div class="pessoa_juridica">
                <label>CNPJ <span class="text-danger">*</span></label>
                <input type="text" class="form-control cnpj" name="cliente_cnpj" placeholder="CNPJ do cliente" value="<?php echo set_value('cliente_cnpj'); ?>">
                <?php echo form_error('cliente_cnpj', '<small class="form-text text-danger">','</small>'); ?>
              </div>
            </div>

            <div class="col-md-3">
              <label class="pessoa_fisica">RG <span class="text-danger">*</span></label>
              <label class="pessoa_juridica">Inscrição estadual <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="cliente_rg_ie" placeholder="RG/IE do cliente" value="<?php echo set_value('cliente_rg_ie'); ?>">
              <?php echo form_error('cliente_rg_ie', '<small class="form-text text-danger">','</small>'); ?>
            </div>

          </div>

          <div class="form-group row mb-4">

            <div class="col-md-5">
              <label>E-mail <span class="text-danger">*</span></label>
              <input type="email" class="form-control" name="cliente_email" placeholder="E-mail do cliente" value="<?php echo set_value('cliente_email'); ?>">
              <?php echo form_error('cliente_email', '<small class="form-text text-danger">','</small>'); ?>
            </div>   

            <div class="col-md-2">
              <label>Telefone</label>
              <input type="text" class="form-control phone_with_ddd" name="cliente_telefone" placeholder="Tel. do cliente" value="<?php echo set_value('cliente_telefone'); ?>">
              <?php echo form_error('cliente_telefone', '<small class="form-text text-danger">','</small>'); ?>
            </div>

            <div class="col-md-2">
              <label>Celular</label>
              <input type="text" class="form-control sp_celphones" name="cliente_celular" placeholder="Cel. do cliente" value="<?php echo set_value('cliente_celular'); ?>">
              <?php echo form_error('cliente_celular', '<small class="form-text text-danger">','</small>'); ?>
            </div>

            <div class="col-md-3">
              <label>Nascimento <span class="text-danger">*</span></label>
              <input type="date" class="form-control" name="cliente_data_nascimento" value="<?php echo set_value('cliente_data_nascimento'); ?>">
              <?php echo form_error('cliente_data_nascimento', '<small class="form-text text-danger">','</small>'); ?>
            </div> 
          </div>
        </fieldset>

        <fieldset class="mt-4 border p-2">
          <legend class="font-small"><i class="fas fa-map-marker-alt"></i>&nbsp;Dados de endereço</legend>
          <div class="form-group row mb-4">

            <div class="col-md-5">
              <label>Endereço <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="cliente_endereco" placeholder="Endereço do cliente" value="<?php echo set_value('cliente_endereco'); ?>">
              <?php echo form_error('cliente_endereco', '<small class="form-text text-danger">','</small>'); ?>
            </div>   

            <div class="col-md-1">
              <label>Nº</label>
              <input type="text" class="form-control " name="cliente_numero_endereco" placeholder="Nº" value="<?php echo set_value('cliente_numero_endereco'); ?>">
              <?php echo form_error('cliente_numero_endereco', '<small class="form-text text-danger">','</small>'); ?>
            </div>

            <div class="col-md-3">
              <label>Bairro <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="cliente_bairro" placeholder="Bairro do cliente" value="<?php echo set_value('cliente_bairro'); ?>">
              <?php echo form_error('cliente_bairro', '<small class="form-text text-danger">','</small>'); ?>
            </div>

            <div class="col-md-3">
              <label>Cidade <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="cliente_cidade" placeholder="Cidade do cliente" value="<?php echo set_value('cliente_cidade'); ?>">
              <?php echo form_error('cliente_cidade', '<small class="form-text text-danger">','</small>'); ?>
            </div> 
          </div>
        </fieldset>


        <fieldset class="mt-4 border p-2">
          <legend class="font-small"><i class="fas fa-cogs"></i>&nbsp;Configurações</legend>
          <div class="form-group row mb-4">

            <div class="col-md-2">
              <label>Cliente ativo</label>
              <select class="custom-select" name="cliente_ativo">
                <option value="0">Não</option>
                <option value="1">Sim</option>
              </select>
            </div>

            <div class="col-md-10">
              <label>Observações</label>
              <textarea type="text" class="form-control" name="cliente_obs" placeholder="Observações sobre o cliente"></textarea>
              <?php echo form_error('cliente_obs', '<small class="form-text text-danger">','</small>'); ?>
            </div>  

          </fieldset>
          <br>

          <a title="Voltar" href="<?php echo base_url('clientes'); ?>" class="btn btn-secondary btn-sm"><span class="icon text-white">
                      <i class="fas fa-arrow-left"></i>
                    </span>&nbsp; Voltar</a>

          <button type="submit" class="btn btn-primary btn-sm ml-3"><span class="icon text-white">
                      <i class="fas fa-save"></i>
                    </span>&nbsp; Salvar</button>
        </form>

      </div>
    </div>

  </div>
  <!-- /.container-fluid -->

</div>
      <!-- End of Main Content -->