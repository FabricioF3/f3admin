	
  <?php $this->load->view('layout/sidebar'); ?>

    
      <!-- Main Content -->
      <div id="content">

      	<?php $this->load->view('layout/navbar'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url('categorias'); ?>">Categorias</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
  </ol>
</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">

<form class="user" method="POST" name="form_edit">

<?php if (isset($categorias)): ?> 
  <p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração:&nbsp;</strong><?php echo formata_data_banco_com_hora($categoria->categoria_data_alteracao); ?></p>
  <?php endif; ?>
  
  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fab fa-buffer"></i>&nbsp;Dados da categoria</legend>
    <div class="form-group row mb-4">
   
    <div class="col-md-8">
      <label>Nome da categoria <span class="text-danger">*</span></label>
      <input type="text" class="form-control" name="categoria_nome" placeholder="Nome da categoria" value="<?php echo set_value('categoria_nome'); ?>">
      <?php echo form_error('categoria_nome', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-4">
      <label>Categoria ativa</label>
      <select class="custom-select" name="categoria_ativa">
        <option value="0">Não</option>
        <option value="1">Sim</option>
      </select>
    </div>
  </div>

    </fieldset>  
  
  
  <div class="form-group row">

    <!--<input type="hidden" name="cliente_tipo" value="<?php echo $cliente->cliente_tipo; ?>"/> --> 
    <!--<input type="hidden" name="marca_id" value="<?php echo $marca->marca_id; ?>"/> --> 

  </div>

  <a title="Voltar" href="<?php echo base_url($this->router->fetch_class()); ?>" class="btn btn-secondary btn-sm"><span class="icon text-white">
                      <i class="fas fa-arrow-left"></i>
                    </span>&nbsp; Voltar</a>
           
  <button type="submit" class="btn btn-primary btn-sm ml-3"><span class="icon text-white">
                      <i class="fas fa-save"></i>
                    </span>&nbsp; Salvar</button>
</form>
      
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->