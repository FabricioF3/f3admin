	
  <?php $this->load->view('layout/sidebar'); ?>

    
      <!-- Main Content -->
      <div id="content">

      	<?php $this->load->view('layout/navbar'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url('fornecedores'); ?>">Fornecedores</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
  </ol>
</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">

<form class="user" method="POST" name="form_edit">

  <p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração:&nbsp;</strong><?php echo formata_data_banco_com_hora($fornecedor->fornecedor_data_alteracao); ?></p>
  
  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-user-tag"></i>&nbsp;Dados pessoais</legend>
    <div class="form-group row mb-4">
   
    <div class="col-md-6">
      <label>Razão social <span class="text-danger">*</span></label>
      <input type="text" class="form-control" name="fornecedor_razao" placeholder="Razão social" value="<?php echo $fornecedor->fornecedor_razao; ?>">
      <?php echo form_error('fornecedor_razao', '<small class="form-text text-danger">','</small>'); ?>
    </div>
   
    <div class="col-md-6">
      <label>Nome fantasia <span class="text-danger">*</span></label>
      <input type="text" class="form-control" name="fornecedor_nome_fantasia" placeholder="Nome fantasia" value="<?php echo $fornecedor->fornecedor_nome_fantasia; ?>">
      <?php echo form_error('fornecedor_nome_fantasia', '<small class="form-text text-danger">','</small>'); ?>
    </div>
  </div>
    
  <div class="form-group row mb-4">

    <div class="col-md-3">
      <label>CNPJ <span class="text-danger">*</span></label>
      <input type="text" class="form-control cnpj" name="fornecedor_cnpj" placeholder="CNPJ" value="<?php echo $fornecedor->fornecedor_cnpj; ?>">
      <?php echo form_error('fornecedor_cnpj', '<small class="form-text text-danger">','</small>'); ?>
    </div>   

    <div class="col-md-3">
      <label>Inscrição estadual <span class="text-danger">*</span></label>
      <input type="text" class="form-control" name="fornecedor_ie" placeholder="Inscrição estadual" value="<?php echo $fornecedor->fornecedor_ie; ?>">
      <?php echo form_error('fornecedor_ie', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Telefone <span class="text-danger">*</span></label>
      <input type="text" class="form-control phone_with_ddd" name="fornecedor_telefone" placeholder="Telefone" value="<?php echo $fornecedor->fornecedor_telefone; ?>">
      <?php echo form_error('fornecedor_telefone', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Celular <span class="text-danger">*</span></label>
      <input type="text" class="form-control sp_celphones" name="fornecedor_celular" placeholder="Celular" value="<?php echo $fornecedor->fornecedor_celular; ?>">
      <?php echo form_error('fornecedor_celular', '<small class="form-text text-danger">','</small>'); ?>
    </div> 

  </div>

  <div class="form-group row mb-4">

    <div class="col-md-6">
      <label>E-mail <span class="text-danger">*</span></label>
      <input type="email" class="form-control" name="fornecedor_email" placeholder="E-mail" value="<?php echo $fornecedor->fornecedor_email; ?>">
      <?php echo form_error('fornecedor_email', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-6">
      <label>Nome do contato</label>
      <input type="text" class="form-control" name="fornecedor_contato" placeholder="Nome do contato" value="<?php echo $fornecedor->fornecedor_contato; ?>">
      <?php echo form_error('fornecedor_contato', '<small class="form-text text-danger">','</small>'); ?>
    </div>

      

  </div>

  </fieldset>

  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-map-marker-alt"></i>&nbsp;Dados de endereço</legend>
    <div class="form-group row mb-4">

    <div class="col-md-5">
      <label>Endereço</label>
      <input type="text" class="form-control" name="fornecedor_endereco" placeholder="Endereço" value="<?php echo $fornecedor->fornecedor_endereco; ?>">
      <?php echo form_error('fornecedor_endereco', '<small class="form-text text-danger">','</small>'); ?>
    </div>   

    <div class="col-md-1">
      <label>Nº</label>
      <input type="text" class="form-control" name="fornecedor_numero_endereco" placeholder="Nº" value="<?php echo $fornecedor->fornecedor_numero_endereco; ?>">
      <?php echo form_error('fornecedor_numero_endereco', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Bairro</label>
      <input type="text" class="form-control" name="fornecedor_bairro" placeholder="Bairro" value="<?php echo $fornecedor->fornecedor_bairro; ?>">
      <?php echo form_error('fornecedor_bairro', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Cidade</label>
      <input type="text" class="form-control" name="fornecedor_cidade" placeholder="Cidade" value="<?php echo $fornecedor->fornecedor_cidade; ?>">
      <?php echo form_error('fornecedor_cidade', '<small class="form-text text-danger">','</small>'); ?>
    </div> 
  </div>
  </fieldset>
  

  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-cogs"></i>&nbsp;Configurações</legend>
    <div class="form-group row mb-4">

    <div class="col-md-2">
      <label>Fornecedor ativo</label>
      <select class="custom-select" name="fornecedor_ativo">
        <option value="0" <?php echo ($fornecedor->fornecedor_ativo == 0 ? 'selected' : ''); ?>>Não</option>
        <option value="1" <?php echo ($fornecedor->fornecedor_ativo == 1 ? 'selected' : ''); ?>>Sim</option>
      </select>
    </div>

    <div class="col-md-10">
      <label>Observações</label>
      <textarea type="text" class="form-control" name="fornecedor_obs" placeholder="Observações sobre o fornecedor"><?php echo $fornecedor->fornecedor_obs; ?></textarea>
      <?php echo form_error('fornecedor_obs', '<small class="form-text text-danger">','</small>'); ?>
    </div>  

  </fieldset>
  
  <div class="form-group row">

    <!--<input type="hidden" name="cliente_tipo" value="<?php echo $cliente->cliente_tipo; ?>"/> --> 
    <input type="hidden" name="fornecedor_id" value="<?php echo $fornecedor->fornecedor_id; ?>"/>   

  </div>

  <a title="Voltar" href="<?php echo base_url($this->router->fetch_class()); ?>" class="btn btn-secondary btn-sm"><span class="icon text-white">
                      <i class="fas fa-arrow-left"></i></span>&nbsp; Voltar</a>
           
  <button type="submit" class="btn btn-primary btn-sm ml-3"><span class="icon text-white">
                      <i class="fas fa-save"></i>
                    </span>&nbsp; Salvar</button>
</form>
      
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->