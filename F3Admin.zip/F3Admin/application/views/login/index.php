  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-6 col-lg-8 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5" style="margin-top: 1rem !important">
          <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
              <div class="col-lg-12">


        <?php if($message = $this->session->flashdata('error')): ?>

          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp;<?php echo $message; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            </div>
          </div>

        <?php endif; ?>

        <?php if($message = $this->session->flashdata('info')): ?>

          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp;<?php echo $message; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            </div>
          </div>

        <?php endif; ?>

                <div class="p-5">
                  <div class="text-center">
                    <div class="text-center">
                            <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 15rem;" src="<?php echo base_url('public/img/LOGO_NOVO.svg'); ?>" alt="">
                        </div>
                    <br>
                  </div>
                 
                  <form class="user" name="form_auth" method="POST" action="<?php echo base_url('login/auth'); ?>">
                    <div class="form-group">
                      <label><i class="fas fa-user"></i>&nbsp; <strong>Email</strong></label>
                      <input type="email" name="email" class="form-control" placeholder="Entre com seu email">
                    </div>
                    <div class="form-group">
                      <label><i class="fas fa-lock"></i>&nbsp; <strong>Senha</strong></label>
                      <input type="password" name="password" class="form-control" placeholder="Entre com sua senha">
                    </div>
                    <br>
                    <button type="submit" class="btn btn-success btn-block"><strong>Entrar</strong></button>
                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>
