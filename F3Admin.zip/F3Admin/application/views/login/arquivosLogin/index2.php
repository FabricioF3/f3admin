<?php
session_start();
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title> F3 SOFTWARES </title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta content="" name="descriptison">
 	<meta content="" name="keywords">
  	<meta name="author" content="F3 SOFTWARES"/>
  	<meta property="og:description" content="Especializada no desenvolvimento de softwares Web & Mobile."/>
  	<meta property="article:author" content='https://f3softwares.com/'/>
  	<meta property="og:tile" content="F3 SOFTWARES | Desenvolvimento Web & Mobile"/>
  	<meta property="b:app_id" content="510578939802878"/>
  	<meta property="og:type" content="website"/>
  	<meta property="og:image" content="https://f3softwares.com/img/logo_compartilhamento.png"/>
  	<meta property="og:image:type" content="image/png"/>
  	<meta property="og:image:width" content="1280"/>
  	<meta property="og:image:heigth" content="720"/>

	<!-- Favicons -->
  	<link href="img/logo.png" rel="shortcut icon">
  	<link href="img/logo.png" rel="apple-touch-icon">
  	
  	
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="img/wave3.png">
	<div class="container">
		<div class="img">
			<img src="img/login-animate2.svg">
		</div>
		<div class="login-content">
			<form action="login.php" method="post">
				<img src="img/LOGO_NOVO.svg"><br>
				<?php 
                        if(isset($_SESSION['nao_autenticado'])): ?>
                        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                            <div class="alert alert-danger" role="alert"><p><small><b> Usuário ou Senha Inválidos!  </b></small></p></div>
                       <?php 
                        endif;
                        unset($_SESSION['nao_autenticado']);
                        ?>
                        
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Usuário</h5>
           		   		<input type="text" class="input">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Senha</h5>
           		    	<input type="password" class="input">
            	   </div>
            	</div>
            	<a href="#">Recuperar senha</a>
            	<br>
            	<input type="submit" class="btn" value="Login">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
