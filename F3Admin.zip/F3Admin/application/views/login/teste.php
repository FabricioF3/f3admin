<?php
session_start();
?>

<?php
// HEADER
include_once 'includes/header_login.php';
?>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form action="login.php" method="post" class="login100-form validate-form p-l-55 p-r-55 p-t-178">
					<span class="login100-form-title">
						<div><img src="img/F3_LOGO_OFICIAL_TRANSPARENTE.png" class="responsive-img" style="width:40%;"></div>
					</span><br><br><br>
                        <?php 
                        if(isset($_SESSION['nao_autenticado'])): ?>
                        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                            <div class="alert alert-danger" role="alert"><p><small><b> Usuário ou Senha Inválidos!  </b></small></p></div>
                       <?php 
                        endif;
                        unset($_SESSION['nao_autenticado']);
                        ?>
					<div class="wrap-input100 validate-input m-b-16" data-validate="Digite seu usuário!">
						<input class="input100" type="text" name="usuario" placeholder="Usuário">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Digite sua senha!">
						<input class="input100" type="password" name="senha" placeholder="Senha">
						<span class="focus-input100"></span>
					</div><br><br>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							ENTRAR
						</button>
					</div>
					<div class="flex-col-c p-t-20 p-b-40"></div>
				</form>
			</div>
		</div>
	</div>
	
<?php
// FOOTER
include_once 'includes/footer_login.php';
?>
	

