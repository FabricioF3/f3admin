<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta content="" name="descriptison">
 	<meta content="" name="keywords">
  	<meta name="author" content="F3 SOFTWARES"/>
  	<meta property="og:description" content="Especializada no desenvolvimento de softwares Web & Mobile."/>
  	<meta property="article:author" content='https://f3softwares.com/'/>
  	<meta property="og:tile" content="F3 SOFTWARES | Desenvolvimento Web & Mobile"/>
  	<meta property="b:app_id" content="510578939802878"/>
  	<meta property="og:type" content="website"/>
  	<meta property="og:image" content="https://f3softwares.com/img/logo_compartilhamento.png"/>
  	<meta property="og:image:type" content="image/png"/>
  	<meta property="og:image:width" content="1280"/>
  	<meta property="og:image:heigth" content="720"/>

	<!-- Favicons -->
  	<link href="img/logo.png" rel="shortcut icon">
  	<link href="img/logo.png" rel="apple-touch-icon">
  	
  	
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="img/wave3.png">
	<div class="container">
		<div class="img">
			<img src="img/login-animate2.svg">
		</div>
		
		<?php if($message = $this->session->flashdata('error')): ?>

          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp;<?php echo $message; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            </div>
          </div>

        <?php endif; ?>

        <?php if($message = $this->session->flashdata('info')): ?>

          <div class="row">
            <div class="col-md-12">
              <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp;<?php echo $message; ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            </div>
          </div>

        <?php endif; ?>
        
		<div class="login-content">
			<form name="form_auth" method="POST" action="<?php echo base_url('login/auth'); ?>">
				<img src="img/logo_training.png"><br><br>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="form-group">
           		   		<h5>Usuário</h5>
           		   		<input type="email" name="email" class="input" placeholder="Entre com seu email">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="form-group">
           		    	<h5>Senha</h5>
           		    	<input type="password" name="password" class="input" placeholder="Entre com seu email">
            	   </div>
            	</div>
            	<br>
            	<input type="submit" class="btn" value="Login">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>