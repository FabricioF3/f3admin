	
  <?php $this->load->view('layout/sidebar'); ?>

    
      <!-- Main Content -->
      <div id="content">

      	<?php $this->load->view('layout/navbar'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url('servicos'); ?>">Serviços</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
  </ol>
</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">

<form class="user" method="POST" name="form_add">

  <?php if (isset($servicos)): ?> 
  <p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração:&nbsp;</strong><?php echo formata_data_banco_com_hora($servico->servico_data_alteracao); ?></p>

    <?php endif; ?>
  
  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-tools"></i>&nbsp;Dados do serviço</legend>
    <div class="form-group row mb-4">
   
    <div class="col-md-6">
      <label>Nome do serviço <span class="text-danger">*</span></label>
      <input type="text" class="form-control" name="servico_nome" placeholder="Nome do serviço" value="<?php echo set_value('servico_nome'); ?>">
      <?php echo form_error('servico_nome', '<small class="form-text text-danger">','</small>'); ?>
    </div>
   
    <div class="col-md-3">
      <label>Preço <span class="text-danger">*</span></label>
      <input type="text" class="form-control money" name="servico_preco" placeholder="Preço do serviço" value="<?php echo set_value('servico_preco'); ?>">
      <?php echo form_error('servico_preco', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Serviço ativo</label>
      <select class="custom-select" name="servico_ativo">
        <option value="0">Não</option>
        <option value="1">Sim</option>
      </select>
    </div>
  </div>

  <div class="form-group row mb-4">

    <div class="col-md-12">
      <label>Descrição do serviço <span class="text-danger">*</span></label>
      <textarea type="text" class="form-control" name="servico_descricao" placeholder="Observações sobre o vendedor" style="min-height: 100px!important"><?php echo set_value('servico_descricao'); ?></textarea>
      <?php echo form_error('servico_descricao', '<small class="form-text text-danger">','</small>'); ?>
    </div> 
  </div>
    </fieldset>  
  
  
  <div class="form-group row">

    <!--<input type="hidden" name="cliente_tipo" value="<?php echo $cliente->cliente_tipo; ?>"/> --> 
    <!-- <input type="hidden" name="vendedor_id" value="<?php echo $vendedor->vendedor_id; ?>"/> -->

  </div>

  <a title="Voltar" href="<?php echo base_url($this->router->fetch_class()); ?>" class="btn btn-secondary btn-sm"><span class="icon text-white">
                      <i class="fas fa-arrow-left"></i>
                    </span>&nbsp; Voltar</a>
           
  <button type="submit" class="btn btn-primary btn-sm ml-3"><span class="icon text-white">
                      <i class="fas fa-save"></i>
                    </span>&nbsp; Salvar</button>
</form>
      
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->