	
  <?php $this->load->view('layout/sidebar'); ?>

    
      <!-- Main Content -->
      <div id="content">

      	<?php $this->load->view('layout/navbar'); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url('vendedores'); ?>">Vendedores</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo $titulo; ?></li>
  </ol>
</nav>

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-body">

<form class="user" method="POST" name="form_edit">

  <p><strong><i class="fas fa-clock"></i>&nbsp;&nbsp;Última alteração:&nbsp;</strong><?php echo formata_data_banco_com_hora($vendedor->vendedor_data_alteracao); ?></p>
  
  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-user-secret"></i>&nbsp;Dados pessoais</legend>
    <div class="form-group row mb-4">
   
    <div class="col-md-6">
      <label>Nome completo <span class="text-danger">*</span></label>
      <input type="text" class="form-control" name="vendedor_nome_completo" placeholder="Nome completo" value="<?php echo $vendedor->vendedor_nome_completo; ?>">
      <?php echo form_error('vendedor_nome_completo', '<small class="form-text text-danger">','</small>'); ?>
    </div>
   
    <div class="col-md-3">
      <label>CPF <span class="text-danger">*</span></label>
      <input type="text" class="form-control cpf" name="vendedor_cpf" placeholder="CPF do vendedor" value="<?php echo $vendedor->vendedor_cpf; ?>">
      <?php echo form_error('vendedor_cpf', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>RG <span class="text-danger">*</span></label>
      <input type="text" class="form-control rg" name="vendedor_rg" placeholder="CPF do vendedor" value="<?php echo $vendedor->vendedor_rg; ?>">
      <?php echo form_error('vendedor_rg', '<small class="form-text text-danger">','</small>'); ?>
    </div>
  </div>
    
  <div class="form-group row mb-4">

    <div class="col-md-6">
      <label>E-mail <span class="text-danger">*</span></label>
      <input type="email" class="form-control" name="vendedor_email" placeholder="E-mail" value="<?php echo $vendedor->vendedor_email; ?>">
      <?php echo form_error('vendedor_email', '<small class="form-text text-danger">','</small>'); ?>
    </div>   

    <div class="col-md-3">
      <label>Telefone <span class="text-danger">*</span></label>
      <input type="text" class="form-control phone_with_ddd" name="vendedor_telefone" placeholder="Telefone" value="<?php echo $vendedor->vendedor_telefone; ?>">
      <?php echo form_error('vendedor_telefone', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Celular <span class="text-danger">*</span></label>
      <input type="text" class="form-control sp_celphones" name="vendedor_celular" placeholder="Celular" value="<?php echo $vendedor->vendedor_celular; ?>">
      <?php echo form_error('vendedor_celular', '<small class="form-text text-danger">','</small>'); ?>
    </div> 

  </div>

  </fieldset>

  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-map-marker-alt"></i>&nbsp;Dados de endereço</legend>
    <div class="form-group row mb-4">

    <div class="col-md-5">
      <label>Endereço</label>
      <input type="text" class="form-control" name="vendedor_endereco" placeholder="Endereço" value="<?php echo $vendedor->vendedor_endereco; ?>">
      <?php echo form_error('vendedor_endereco', '<small class="form-text text-danger">','</small>'); ?>
    </div>   

    <div class="col-md-1">
      <label>Nº</label>
      <input type="text" class="form-control" name="vendedor_numero_endereco" placeholder="Nº" value="<?php echo $vendedor->vendedor_numero_endereco; ?>">
      <?php echo form_error('vendedor_numero_endereco', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Bairro</label>
      <input type="text" class="form-control" name="vendedor_bairro" placeholder="Bairro" value="<?php echo $vendedor->vendedor_bairro; ?>">
      <?php echo form_error('vendedor_bairro', '<small class="form-text text-danger">','</small>'); ?>
    </div>

    <div class="col-md-3">
      <label>Cidade</label>
      <input type="text" class="form-control" name="vendedor_cidade" placeholder="Cidade" value="<?php echo $vendedor->vendedor_cidade; ?>">
      <?php echo form_error('vendedor_cidade', '<small class="form-text text-danger">','</small>'); ?>
    </div> 
  </div>
  </fieldset>
  

  <fieldset class="mt-4 border p-2">
    <legend class="font-small"><i class="fas fa-cogs"></i>&nbsp;Configurações</legend>
    <div class="form-group row mb-4">

    <div class="col-md-2">
      <label>Fornecedor ativo</label>
      <select class="custom-select" name="vendedor_ativo">
        <option value="0" <?php echo ($vendedor->vendedor_ativo == 0 ? 'selected' : ''); ?>>Não</option>
        <option value="1" <?php echo ($vendedor->vendedor_ativo == 1 ? 'selected' : ''); ?>>Sim</option>
      </select>
    </div>

    <div class="col-md-2">
      <label>Matrícula</label>
      <input type="text" class="form-control" name="vendedor_codigo" placeholder="Matrícula" value="<?php echo $vendedor->vendedor_codigo; ?>" readonly="">
      <?php echo form_error('vendedor_codigo', '<small class="form-text text-danger">','</small>'); ?>
    </div> 

    <div class="col-md-8">
      <label>Observações</label>
      <textarea type="text" class="form-control" name="vendedor_obs" placeholder="Observações sobre o vendedor"><?php echo $vendedor->vendedor_obs; ?></textarea>
      <?php echo form_error('vendedor_obs', '<small class="form-text text-danger">','</small>'); ?>
    </div>  

  </fieldset>
  
  <div class="form-group row">

    <!--<input type="hidden" name="cliente_tipo" value="<?php echo $cliente->cliente_tipo; ?>"/> --> 
    <input type="hidden" name="vendedor_id" value="<?php echo $vendedor->vendedor_id; ?>"/>   

  </div>

  <a title="Voltar" href="<?php echo base_url($this->router->fetch_class()); ?>" class="btn btn-secondary btn-sm"><span class="icon text-white">
                      <i class="fas fa-arrow-left"></i>
                    </span>&nbsp; Voltar</a>
           
  <button type="submit" class="btn btn-primary btn-sm ml-3"><span class="icon text-white">
                      <i class="fas fa-save"></i>
                    </span>&nbsp; Salvar</button>
</form>
      
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->